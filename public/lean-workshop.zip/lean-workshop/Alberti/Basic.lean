/-
# Alberti's cipher disk, as on the Church of Cryptography 40C3 coin

Definitions only; the proofs live in `Alberti/Exercises.lean` (you fill them in).
The facilitator's copy also has `Alberti/Solutions.lean`, the answer key.

The coin has two rings of 36 cells each:

* the fixed **outer ring** `A..Z 0..9` (the plaintext alphabet), and
* the turning **inner disk** of 36 distinct lowercase Latin and Greek
  letters (the ciphertext alphabet).

A cell is just a number `0..35`, so we name a cell with `Fin 36`:
"a natural number below 36". Arithmetic on `Fin 36` wraps around
(`35 + 1 = 0`), which is exactly what turning a disk does.

Nothing here needs Mathlib: only Lean core.
-/

namespace Alberti

/-- A cell position on the coin: 0, 1, ..., 35. -/
abbrev Sym := Fin 36

/-- Outer ring, clockwise from the top: `ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789`. -/
def outerList : List Char :=
  ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R',
   'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9']

/-- Inner disk, clockwise from the top: `θξδgovyσαπβψcwteradzpζxnφhqimfluksbj`.
(A Fisher–Yates shuffle driven by SHA-256; see the coin's card.) -/
def diskList : List Char :=
  ['θ', 'ξ', 'δ', 'g', 'o', 'v', 'y', 'σ', 'α', 'π', 'β', 'ψ', 'c', 'w', 't', 'e', 'r', 'a',
   'd', 'z', 'p', 'ζ', 'x', 'n', 'φ', 'h', 'q', 'i', 'm', 'f', 'l', 'u', 'k', 's', 'b', 'j']

theorem outerList_length : outerList.length = 36 := rfl
theorem diskList_length : diskList.length = 36 := rfl

/-- The symbol printed in outer cell `i`. -/
def outer (i : Sym) : Char := outerList[i.val]'(by rw [outerList_length]; exact i.isLt)

/-- The symbol printed in disk cell `i`. -/
def disk (i : Sym) : Char := diskList[i.val]'(by rw [diskList_length]; exact i.isLt)

/-- The dotted key mark: disk cell 32, the letter `k`. -/
def keyMark : Sym := 32

/-- Where is character `c` on a ring?  `none` if it is not printed there. -/
def indexOf? (ring : Sym → Char) (c : Char) : Option Sym :=
  (List.finRange 36).find? (fun i => ring i == c)

/-- Turning `k` under the outer cell `key` rotates the disk by this many cells. -/
def shiftOf (key : Sym) : Sym := key - keyMark

/-- With the disk rotated by `s`, outer cell `i` sits above disk cell `i - s`. -/
def encIdx (s i : Sym) : Sym := i - s

/-- ...and disk cell `j` sits below outer cell `j + s`. -/
def decIdx (s j : Sym) : Sym := j + s

/-! ## Character level -/

/-- Encrypt one plaintext character (must be on the outer ring). -/
def encryptChar (s : Sym) (p : Char) : Option Char :=
  (indexOf? outer p).map fun i => disk (encIdx s i)

/-- Decrypt one ciphertext character (must be on the disk). -/
def decryptChar (s : Sym) (c : Char) : Option Char :=
  (indexOf? disk c).map fun j => outer (decIdx s j)

/-! ## Message level

`List.mapM` applies an `Option`-valued function to every element and fails
(`none`) as soon as one element fails. -/

def encryptBody (s : Sym) (msg : List Char) : Option (List Char) :=
  msg.mapM (encryptChar s)

def decryptBody (s : Sym) (ct : List Char) : Option (List Char) :=
  ct.mapM (decryptChar s)

/-- One segment: the key letter in clear, then the encrypted letters. -/
def encryptSeg (key : Char) (msg : List Char) : Option (List Char) := do
  let k ← indexOf? outer key
  let body ← encryptBody (shiftOf k) msg
  pure (key :: body)

/-- Encrypt `msg` (capitals and digits only, no spaces) with key letter `key`. -/
def encrypt (key : Char) (msg : String) : Option String :=
  (encryptSeg key msg.toList).map String.ofList

/-- Read the clear key letter, set the disk, decrypt the rest. -/
def decryptList : List Char → Option (List Char)
  | [] => none
  | key :: body => do
      let k ← indexOf? outer key
      decryptBody (shiftOf k) body

def decrypt (ct : String) : Option String :=
  (decryptList ct.toList).map String.ofList

/-! ## Test vectors (checked by the compiler on every `lake build`) -/

#guard encrypt 'D' "HELLO40C3" == some "Dθsooσnzux"
#guard encrypt 'C' "FINDUSATMILLIWAYS" == some "Cjδσstclwyδvvδrldc"
#guard decrypt "Dθsooσnzux" == some "HELLO40C3"
#guard decrypt "Cjδσstclwyδvvδrldc" == some "FINDUSATMILLIWAYS"
#guard encrypt 'D' "hello" == none   -- lowercase is not on the outer ring

/-! ## Symbol level (total functions, used for the "is it secure?" part)

Here a plaintext is already a list of outer-ring cells, so nothing can fail. -/

def encSyms (s : Sym) (m : List Sym) : List Char :=
  m.map fun i => disk (encIdx s i)

def decSyms (s : Sym) (ct : List Char) : Option (List Sym) :=
  ct.mapM fun c => (indexOf? disk c).map (decIdx s)

/-- Try every one of the 36 settings on a ciphertext body (key letter removed). -/
def bruteForce (body : String) : List String :=
  (List.finRange 36).filterMap fun k =>
    (decryptBody (shiftOf k) body.toList).map fun p =>
      s!"{outer k}: {String.ofList p}"

/-! ## Stretch: Alberti's mid-message key change

The disk symbols (lowercase, Greek) and the outer ring (capitals, digits) are
disjoint. So a capital can appear in the ciphertext stream: it means
"turn the disk so `k` is under this capital" and is not itself a message letter. -/

/-- Decrypt a stream, keeping the current disk setting as state. -/
def decryptStream : Option Sym → List Char → Option (List Char)
  | _, [] => some []
  | cur, c :: cs =>
    match indexOf? outer c with
    | some k => decryptStream (some k) cs            -- clear capital: re-set the disk
    | none =>
      match cur with
      | none => none                                 -- cipher symbol before any setting
      | some k => do
          let p ← decryptChar (shiftOf k) c
          let rest ← decryptStream (some k) cs
          pure (p :: rest)

/-- Encrypt several segments, each with its own key letter, and concatenate. -/
def encryptSegs : List (Char × List Char) → Option (List Char)
  | [] => some []
  | (k, m) :: segs => do
      let a ← encryptSeg k m
      let b ← encryptSegs segs
      pure (a ++ b)

def encryptMulti (segs : List (Char × String)) : Option String :=
  (encryptSegs (segs.map fun (k, m) => (k, m.toList))).map String.ofList

def decryptMulti (ct : String) : Option String :=
  (decryptStream none ct.toList).map String.ofList

#guard encryptMulti [('D', "HELLO"), ('Q', "40C3")] == some "DθsooσQβydπ"
#guard decryptMulti "DθsooσQβydπ" == some "HELLO40C3"

end Alberti
