/-
# Exercises: proving Alberti's cipher correct (and seeing why that is not enough)

Replace each `sorry` with a proof. Work top to bottom: the levels get harder,
and later exercises may use earlier ones (even unproved ones; Lean lets you
use a `sorry`ed lemma, it just warns).

How to work:
* Put your cursor inside a `by` block and watch the **Lean Infoview** panel
  (VS Code: `Ctrl+Shift+Enter` opens it). It shows the goal: what is left to prove.
* No red squiggles and only "declaration uses `sorry`" warnings means it builds.
* Stuck for more than 5 minutes? Read the hint; then ask a facilitator,
  who has the answer key. Asking is allowed.

Tactic cheat sheet (all core Lean, no Mathlib):
  `rfl`        both sides compute to the same thing
  `decide`     a finite yes/no question: Lean checks every case
  `intro x`    assume `x` / take an arbitrary `x`
  `revert x`   the opposite of `intro`
  `unfold f`   replace `f` by its definition
  `simp [h]`   simplify using the lemmas in brackets (and standard ones)
  `simp at h`  simplify a hypothesis
  `cases h : e with | none => .. | some x => ..`   split on an `Option`
  `subst h`    `h : x = e`: replace `x` by `e` everywhere
  `induction l with | nil => .. | cons a l ih => ..`
  `omega`      linear arithmetic over `Nat` / `Int`
  `exact e`    "here is the proof term"
  `exact?`     ask Lean to search for a lemma (slow but handy)
-/
import Alberti.Basic

namespace Alberti.Exercises
open Alberti

/-! ## Level −1: hello, Lean (no proofs yet)

Hover over things. Click on `#eval` lines and read the output in the Infoview. -/

#eval outerList.length          -- 36
#eval disk 32                   -- 'k'
#eval encrypt 'D' "HELLO40C3"   -- the vector printed on the coin's card
#eval decrypt "Dθsooσnzux"
#check @encrypt                 -- Char → String → Option String

-- Try: encrypt your own nickname (CAPITALS and digits, no spaces).
-- #eval encrypt 'Q' "YOURNAME"

/-! ## Level 0: warm-up -/

/-- Ex 0.1: the key mark really is the letter `k`.
Hint: both sides are concrete; `rfl` or `decide`. -/
theorem disk_keyMark : disk keyMark = 'k' := by
  sorry

/-- Ex 0.2: the coin's check vector, as a theorem.
Hint: `decide`. -/
theorem hello_vector : encrypt 'D' "HELLO40C3" = some "Dθsooσnzux" := by
  sorry

/-- Ex 0.3 -/
theorem milliways_vector : encrypt 'C' "FINDUSATMILLIWAYS" = some "Cjδσstclwyδvvδrldc" := by
  sorry

/-- Ex 0.4: **Use the coin (or paper disk).** Put `k` under `K`, encrypt
ATTACKATDAWN by hand and replace `????` with your answer. Then prove it.
If Lean says no, either you or the coin is wrong: find out which with `#eval`. -/
theorem attack_vector : encrypt 'K' "ATTACKATDAWN" = some "K????" := by
  sorry

/-! ## Level 1: facts about a finite object, by exhaustive check

`decide` asks the Lean kernel to check every case. With 36 symbols, that is at
most 36 × 36 = 1296 cases. This is a real proof, not a unit test. -/

/-- Ex 1.1: turning the disk back undoes turning it forward.
Hint: `decide`. Then look at `encIdx` and `decIdx` in `Basic.lean`. -/
theorem decIdx_encIdx : ∀ s i : Sym, decIdx s (encIdx s i) = i := by
  sorry

/-- Ex 1.2: ...and the other way round. 1.1 + 1.2 say: for a fixed setting,
the map on the 36 cells is a **bijection** with inverse `decIdx s`. -/
theorem encIdx_decIdx : ∀ s j : Sym, encIdx s (decIdx s j) = j := by
  sorry

/-- Ex 1.3: the disk is a permutation: no symbol is printed twice.
Hint: `Function.Injective disk` means `∀ a b, disk a = disk b → a = b`.
`decide` needs the `∀`s in front: `intro a b`, then `revert a b`, then `decide`. -/
theorem disk_injective : Function.Injective disk := by
  sorry

/-- Ex 1.4: same for the outer ring. -/
theorem outer_injective : Function.Injective outer := by
  sorry

/-- Ex 1.5: looking a symbol up finds the right cell. -/
theorem indexOf?_outer : ∀ i, indexOf? outer (outer i) = some i := by
  sorry

theorem indexOf?_disk : ∀ i, indexOf? disk (disk i) = some i := by
  sorry

/-- Ex 1.6: the two rings share no symbol. -/
theorem indexOf?_outer_disk : ∀ i, indexOf? outer (disk i) = none := by
  sorry

/-! ## Level 2 (optional detour): the same arithmetic for *every* modulus

`decide` only worked because 36 is small. Here `n` is arbitrary, so we must
actually reason. Skip to Level 3 if this eats more than 10 minutes. -/

/-- Ex 2.1
Hint: `apply Fin.ext` reduces to an equation of `Nat` values.
`simp only [Fin.sub_def, Fin.add_def]` exposes the `% n`.
`Nat.mod_add_mod : (m % n + k) % n = (m + k) % n`.
`omega` can't do `% n` for variable `n`, but it can prove
`n - b + a + b = a + n` given `a < n` and `b < n` (get them from `a.isLt`, `b.isLt`).
Finish with `Nat.add_mod_right` and `Nat.mod_eq_of_lt`. -/
theorem fin_sub_add_cancel {n : Nat} (a b : Fin n) : a - b + b = a := by
  sorry

/-- Ex 2.2  Hint: as 2.1, with `Nat.add_mod_mod : (m + n % k) % k = (m + n) % k`. -/
theorem fin_add_sub_cancel {n : Nat} (a b : Fin n) : a + b - b = a := by
  sorry

/-! ## Level 3: correctness, character then message -/

/-- Ex 3.1: if lookup succeeds, the ring really shows that character there.
Hint: `unfold indexOf? at h`, then `List.find?_some h` gives `(ring i == c) = true`;
`simpa using List.find?_some h` turns that into `ring i = c`. -/
theorem indexOf?_spec {ring : Sym → Char} {c : Char} {i : Sym}
    (h : indexOf? ring c = some i) : ring i = c := by
  sorry

/-- Ex 3.2: character-level correctness.
Hint: `unfold encryptChar at h`, then `cases hi : indexOf? outer p with`.
The `none` case is contradictory (`simp [hi] at h`). In the `some i` case,
`simp [hi] at h` gives `h : disk (encIdx s i) = c`; `subst h`; then
`simp [decryptChar, indexOf?_disk, decIdx_encIdx, indexOf?_spec hi]`. -/
theorem decryptChar_encryptChar {s : Sym} {p c : Char}
    (h : encryptChar s p = some c) : decryptChar s c = some p := by
  sorry

/-- Ex 3.3: message-level correctness.
Hint: `intro m`, then `induction m with` (or write it as a recursive proof by
pattern matching; see the solutions). In the step case, `List.mapM_cons` says how
`mapM` handles `p :: m`; split on `encryptChar s p` and on the `mapM` of the rest,
exactly as in 3.2, and use 3.2 and the induction hypothesis.
Remember `intro ct h` after `induction` (or use `induction m generalizing ct`). -/
theorem decryptBody_encryptBody {s : Sym} :
    ∀ {m ct : List Char}, encryptBody s m = some ct → decryptBody s ct = some m := by
  sorry

/-- Ex 3.4: **the main theorem.** For every key letter and every message:
whenever encryption succeeds, decryption gives the message back.
Hint: `unfold encrypt encryptSeg at h`; split on `indexOf? outer key` and on
`encryptBody (shiftOf k) msg.toList`; then
`simp [decrypt, decryptList, String.toList_ofList, hk, decryptBody_encryptBody hb]`. -/
theorem decrypt_encrypt {key : Char} {msg ct : String}
    (h : encrypt key msg = some ct) : decrypt ct = some msg := by
  sorry

/-- Ex 3.5: 3.4 is not vacuous: encryption does succeed on every message over the
alphabet. First a finite check (Hint: `decide`), then induction. -/
theorem indexOf?_outer_isSome : ∀ c ∈ outerList, (indexOf? outer c).isSome := by
  sorry

/-- Hint: induction on `m`. `Option.isSome_iff_exists` turns `isSome` into `∃ x, _ = some x`. -/
theorem encryptBody_isSome {s : Sym} :
    ∀ {m : List Char}, (∀ c ∈ m, c ∈ outerList) → (encryptBody s m).isSome := by
  sorry

theorem encrypt_isSome {key : Char} {msg : String}
    (hk : key ∈ outerList) (hm : ∀ c ∈ msg.toList, c ∈ outerList) :
    (encrypt key msg).isSome := by
  sorry

/-! ## Level 4: correct is not the same as secure

Everything above says "the cipher works". Nothing above says "an attacker
learns nothing". The next statements are just as true, and they are bad news. -/

/-- Ex 4.1: for a fixed setting, different letters give different cipher letters.
Hint: apply `decryptChar_encryptChar` to both hypotheses and compare. -/
theorem encryptChar_injective {s : Sym} {p q c : Char}
    (hp : encryptChar s p = some c) (hq : encryptChar s q = some c) : p = q := by
  sorry

/-- Ex 4.2: **the leak.** Under one setting, two ciphertext positions carry the
same symbol *if and only if* the plaintext letters there are equal. Double
letters, repeated words and letter frequencies all survive encryption.
Hint: `simp only [encSyms, List.getElem_map]`, `constructor`. For `→` use
`disk_injective`, then `congrArg (decIdx s)` and `decIdx_encIdx`. -/
theorem encSyms_eq_iff (s : Sym) (m : List Sym) (i j : Nat)
    (hi : i < (encSyms s m).length) (hj : j < (encSyms s m).length) :
    (encSyms s m)[i] = (encSyms s m)[j] ↔
      m[i]'(by simpa [encSyms] using hi) = m[j]'(by simpa [encSyms] using hj) := by
  sorry

/-- Ex 4.3: decrypting a symbol list. Hint: induction; `List.map_cons`, `List.mapM_cons`. -/
theorem decSyms_encSyms (s : Sym) : ∀ m : List Sym, decSyms s (encSyms s m) = some m := by
  sorry

/-- Ex 4.4: **brute force always works.** Even if the key letter were kept
secret, the plaintext is among the 36 candidates from trying every setting.
Hint: you already know the right `s'`. `exact ⟨s, List.mem_finRange s, ?_⟩`. -/
theorem brute_force_complete (s : Sym) (m : List Sym) :
    ∃ s' ∈ List.finRange 36, decSyms s' (encSyms s m) = some m := by
  sorry

-- Now run the attack. Which line is English?
#eval bruteForce "θsooσnzux"

/-! ## Level 5 (stretch): Alberti's mid-message key change

Read `decryptStream`, `encryptSegs` and `encryptMulti` in `Basic.lean` first. -/

/-- Ex 5.1: an encrypted body under setting `k`, followed by anything, decrypts
to the body's plaintext followed by whatever the rest decrypts to.
Hint: induction on `m`. You need: a disk symbol is not a clear capital
(`indexOf?_outer_disk`), and `decryptChar_encryptChar`. -/
theorem decryptStream_body {k : Sym} :
    ∀ {m b : List Char} (rest : List Char), encryptBody (shiftOf k) m = some b →
      decryptStream (some k) (b ++ rest) = (decryptStream (some k) rest).map (m ++ ·) := by
  sorry

/-- Ex 5.2: **correctness with key changes**, from any starting setting.
Hint: induction on `segs` (generalizing `cur` and `ct`); unfold one `encryptSeg`. -/
theorem decryptStream_encryptSegs :
    ∀ (cur : Option Sym) {segs : List (Char × List Char)} {ct : List Char},
      encryptSegs segs = some ct → decryptStream cur ct = some (segs.flatMap Prod.snd) := by
  sorry

/-- Ex 5.3: the same, for strings. Hint: `String.toList_ofList`,
`String.ofList_toList`, `String.toList_join`. -/
theorem decryptMulti_encryptMulti {segs : List (Char × String)} {ct : String}
    (h : encryptMulti segs = some ct) :
    decryptMulti ct = some (String.join (segs.map Prod.snd)) := by
  sorry

end Alberti.Exercises
