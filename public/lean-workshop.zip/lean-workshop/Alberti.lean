-- Library root: `lake build` checks both files.
import Alberti.Basic
import Alberti.Exercises
