# Proving Alberti's Cipher in Lean: handout

Church of Cryptography · Milliways · 40C3

## 1. Get running (pick one)

* **Installed**: in this folder run `lake build`, open the *folder* in VS Code with the Lean 4 extension, open `Alberti/Exercises.lean`, press `Ctrl+Shift+Enter` for the Infoview.
* **No network**: ask for the USB stick and follow "At congress, offline" in `README.md`.
* **No install**: paste `live/AlbertiLive.lean` into https://live.lean-lang.org.

A successful build ends in `Build completed successfully` and shows only "declaration uses `sorry`" warnings.

## 2. The cipher on your coin

Outer ring `ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789`. Inner disk `θξδgovyσαπβψcwteradzpζxnφhqimfluksbj`.
Turn the disk so the dotted **k** sits under your key capital, write that capital in clear, then
replace each letter by the disk symbol under it. Check: `HELLO40C3` with key `D` gives `Dθsooσnzux`.

In Lean, a cell is a `Fin 36`: a number below 36 whose arithmetic wraps (`35 + 1 = 0`), just like the disk.
Read `Alberti/Basic.lean` (about 160 lines) for the definitions.

## 3. The exercises (`Alberti/Exercises.lean`)

| Level | You prove | Main tool |
|---|---|---|
| 0 | The test vectors. Ex 0.4: do it on the coin first, then let Lean check you | `decide` |
| 1 | The disk is a permutation; shifting back undoes shifting | `decide` (all 36 × 36 cases) |
| 2 *(optional)* | `a - b + b = a` in every `Fin n` | `Fin.ext`, `omega` |
| 3 | **decrypt (encrypt m) = m, for every key and message** | `cases`, `simp`, induction |
| 4 | **...and it is still broken**: equal letters ⇔ equal cipher letters; brute force over 36 keys always works | injectivity |
| 5 *(stretch)* | Correctness with Alberti's mid-message key changes | induction |

Stuck for 5 minutes? Read the hint above the `sorry`. Still stuck? Ask a facilitator: they have the answer key.

## 4. Tactic cheat sheet

| Tactic | Use it when |
|---|---|
| `rfl` | both sides compute to the same value |
| `decide` | a finite yes/no question: Lean checks every case |
| `intro x` / `revert x` | move a `∀` or `→` into / out of your assumptions |
| `unfold f` | you need to see inside definition `f` |
| `simp [h₁, h₂]` / `simp at h` | rewrite with lemmas until nothing changes |
| `cases h : e with \| none => _ \| some x => _` | `e` is an `Option`: handle both outcomes |
| `subst h` | `h : x = e` and you want `e` everywhere instead of `x` |
| `induction l with \| nil => _ \| cons a l ih => _` | a statement about every list |
| `omega` | linear arithmetic on `Nat` / `Int` |
| `exact?` | ask Lean to find a lemma for you |

Typing: `\forall` ∀, `\to` →, `\theta` θ, `\sigma` σ, `\iff` ↔, `\ne` ≠ (then space).

## 5. The point

Level 3 proves the cipher **correct**. Level 4 proves, just as rigorously, that it is **not secure**: the key
space has 36 elements and a fixed setting preserves letter frequencies. A proof only covers what its statement says.
Real security statements are games against an adversary with bounded resources, and computational security
rests on hardness assumptions that we can reduce to but not prove. **For real secrets, use modern end-to-end encryption.**

## 6. Read next

* HashCloak, *Introduction to Formal Verification with Lean (Part 1)*: one-time pad correctness in Lean.
  hashcloak.com/blog/tutorial-introduction-to-formal-verification-with-lean-(part-1)
* Dziembowski, Fabiański, Micciancio, Stefański, *Computationally-Sound Symbolic Cryptography in Lean*,
  IACR ePrint 2025/1700, eprint.iacr.org/2025/1700. From symbolic proofs to computational security, in Lean 4.
* lean-lang.org/documentation: *Theorem Proving in Lean 4*, *Functional Programming in Lean*.

*In cryptographia confidimus, per mathesin transcendimus.*
