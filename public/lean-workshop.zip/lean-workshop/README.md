# Formal Verification Quick-Dive: Proving Alberti's Cipher in Lean

Workshop #9 of the Church of Cryptography assembly at 40C3 (Hamburg, 27–30 Dec 2026).
About 10 people with laptops, 75–90 minutes, no prior Lean needed.

Participants prove that the Alberti disk on the assembly coin decrypts what it
encrypts, for every key and every message. Then they prove facts that show why
the cipher is still broken. The point of the session is the difference between
"proved correct" and "proved secure".

## What is in here

| Path | What it is |
|---|---|
| `Alberti/Basic.lean` | The cipher: alphabets, shift, `encryptChar`/`decryptChar`, `encrypt`/`decrypt` with the key letter prefix, brute force, mid-message key change. Test vectors as `#guard`, checked on every build. |
| `Alberti/Exercises.lean` | 27 statements with `sorry`, easy to hard, hints in comments. Participants work here. |
| `Alberti/Solutions.lean` | **Answer key** (facilitator copy only). Same names, same order, no `sorry`. |
| `live/AlbertiLive.lean` | Basic + Exercises in one import-free file, for https://live.lean-lang.org (no install). Regenerate with `scripts/make-live.sh`. |
| `HANDOUT.md` | One page for participants' laptops. |
| `lean-toolchain`, `lakefile.toml` | Lake project pinned to `leanprover/lean4:v4.35.0`. **No dependencies** (no Mathlib). |

The answer key is in this folder but not in the participant download
(`cryptography.church/lean-workshop.zip`, built by `site/build_lean.py`), which leaves out
`Alberti/Solutions.lean` and its import line in `Alberti.lean`. If you hand out a copy
of this folder instead, delete both yourself. In the download, the facilitator notes
below refer to a file participants don't have.

## The cipher (must match the coin)

* Outer ring `ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789`, fixed.
* Inner disk `θξδgovyσαπβψcwteradzpζxnφhqimfluksbj`; the key mark is cell 32, the `k`.
* Key letter `K`: shift `s = (index(K) − 32) mod 36`; plaintext `p` becomes `DISK[(index(p) − s) mod 36]`.
  The ciphertext is `K` in clear followed by the cipher letters.
* Check vectors, all verified by `lake build`:
  `HELLO40C3` with key `D` gives `Dθsooσnzux`;
  `FINDUSATMILLIWAYS` with key `C` gives `Cjδσstclwyδvvδrldc`;
  `ATTACKATDAWN` with key `K` gives `Kxvvxφkxvhxαj` (answer to Ex 0.4);
  segments `D:HELLO` then `Q:40C3` give `DθsooσQβydπ`.

In Lean, a cell is a `Fin 36` (a number below 36). `Fin` arithmetic wraps
around, so turning the disk is plain `+` and `-`. Everything uses Lean core
only.

## Setup

### Why no Mathlib

Mathlib would add a multi-gigabyte cache download (`lake exe cache get`) to
every laptop over congress wifi. Nothing here needs it. `Fin 36`, `List`,
`Option` and the core tactics (`decide`, `simp`, `omega`, `induction`) are
enough. The only download is the Lean toolchain itself.

### Before congress (participants, about 10 minutes on a good connection)

1. Install elan, the Lean version manager:
   * Linux/macOS: `curl https://elan.lean-lang.org/elan-init.sh -sSf | sh -s -- -y`
   * Windows: see https://lean-lang.org/install/ (or use WSL and the line above).
2. Install VS Code and the **Lean 4** extension (`leanprover.lean4`). Emacs and Neovim (`lean.nvim`) also work.
3. Get this folder and run `lake build` inside it. The first run downloads
   Lean 4.35.0: about 570–600 MB on Linux/macOS (about 900 MB on Windows),
   3 GB unpacked. After that a build takes about 2 seconds and needs no network.
4. Open the folder in VS Code (the folder, not a single file) and open `Alberti/Exercises.lean`.

Expected result of step 3: `Build completed successfully`, plus "declaration
uses `sorry`" warnings from `Exercises.lean` only.

### At congress, offline (facilitator brings a USB stick)

Put on the stick:
* this folder;
* the toolchain archives from https://github.com/leanprover/lean4/releases/tag/v4.35.0
  (`lean-4.35.0-linux.tar.zst`, `-linux_aarch64.tar.zst`, `-darwin.tar.zst`, `-darwin_aarch64.tar.zst`, `-windows.zip`);
* the elan installer script and the VS Code Lean 4 extension as a `.vsix`.

A participant with elan but no toolchain unpacks the archive for their
platform, then runs this inside the project folder:

```sh
elan toolchain link lean-4.35.0 /path/to/unpacked/lean-4.35.0-<platform>
elan override set lean-4.35.0
lake build
```

(This link-and-override workflow was tested here with elan 4.2.4.)

### No install at all

Open https://live.lean-lang.org and paste the whole of `live/AlbertiLive.lean`.
It runs in the browser. The web editor may run a slightly different Lean
version than 4.35.0; the proofs use only stable core features, but this path
has not been tested.

## Agenda (80 minutes, 10 minutes slack)

| Time | Block | What happens |
|---|---|---|
| 0:00–0:05 | **Alberti in your hand** | Hand out coins or paper disks (`site/paper/alberti-paper-{a4,letter}.pdf`). Everyone sets `k` under `D` and encrypts `HELLO40C3`. Check against the card: `D θsooσnzux`. |
| 0:05–0:20 | **Lean crash course** (projector, live) | Walk through `Basic.lean`: `def`, `Fin 36` wraps (`#eval (35 : Fin 36) + 1`), `Option` for "this character is not on the ring", `#eval encrypt 'D' "HELLO40C3"`. Then one proof each way: `rfl` (compute), `decide` (check all cases), and a `cases`/`simp` proof with the Infoview open. Show `sorry` and `#print axioms`. |
| 0:20–0:30 | **Exercises, Levels 0–1** | Test vectors as theorems. Ex 0.4: encrypt `ATTACKATDAWN` with key `K` on the coin, type the answer in, prove it with `decide`. Disk is a permutation, shift is invertible: all by `decide` over 36 × 36 cases. |
| 0:30–0:55 | **Exercises, Level 3** (Level 2 optional) | Character then message correctness, ending in `decrypt_encrypt`: for every key and message, decrypt undoes encrypt. Walk around and unstick people. At 0:45, show the solution of 3.2 on the projector so everyone can do 3.3–3.4. |
| 0:55–1:10 | **Correct ≠ secure** (Level 4 + discussion) | Run `#eval bruteForce "θsooσnzux"` together: 36 candidates, one is English. Prove `encSyms_eq_iff` (equal plaintext letters ⇔ equal ciphertext letters). Discussion below. |
| 1:10–1:20 | **Where this goes** | Closing pointers (below). Level 5 (mid-message key change) as take-home. |

If the group is fast, do Level 5 live after Level 4. If it is slow, skip Level 2
and do 3.5 and 4.3 as demos.

## Facilitator notes

### What is proved (all in `Solutions.lean`, no `sorry`; `#print axioms` shows only `propext`, `Classical.choice`, `Quot.sound`, so no `native_decide`)

| Level | Theorem | Statement | Proof style |
|---|---|---|---|
| 0 | `disk_keyMark`, `hello_vector`, `milliways_vector`, `attack_vector` | Key mark is `k`; the test vectors | `rfl`, `decide` |
| 1 | `decIdx_encIdx`, `encIdx_decIdx` | Shift and unshift are inverse (bijection on 36 cells) | `decide` |
| 1 | `disk_injective`, `outer_injective` | Each ring is a permutation | `decide` |
| 1 | `indexOf?_outer`, `indexOf?_disk`, `indexOf?_outer_disk` | Lookup is correct; rings are disjoint | `decide` |
| 2 | `fin_sub_add_cancel`, `fin_add_sub_cancel` | `a - b + b = a` in any `Fin n` | `Fin.ext`, `Nat` mod lemmas, `omega` |
| 3 | `indexOf?_spec`, `decryptChar_encryptChar` | Char-level correctness | `cases`, `simp` |
| 3 | `decryptBody_encryptBody`, **`decrypt_encrypt`** | Message-level correctness for every key and message | induction |
| 3 | `encryptBody_isSome`, `encrypt_isSome` | Encryption succeeds on every message over the alphabet | induction |
| 4 | `encryptChar_injective` | Fixed key: distinct letters, distinct cipher letters | from Level 3 |
| 4 | **`encSyms_eq_iff`** | Fixed key: `ct[i] = ct[j] ↔ m[i] = m[j]` (the frequency leak) | `List.getElem_map`, injectivity |
| 4 | `decSyms_encSyms`, **`brute_force_complete`**, `keyspace_size` | The plaintext is always among the 36 candidates | induction, witness |
| 5 | `decryptStream_body`, `decryptStream_encryptSegs`, `decryptMulti_encryptMulti` | Correctness with Alberti's mid-message key changes, from any starting setting | induction |

### Talking points: correctness vs hardness

* Everything in Levels 0–3 says *the cipher works*. None of it says *an attacker learns nothing*. A proof is only as good as its statement.
* Level 4 proves bad news with the same rigour: `brute_force_complete` and `encSyms_eq_iff` are theorems too. Formal methods prove attacks as readily as defences.
* On this coin the disk order is public and the key letter travels in clear, so there is no secret at all. Even with a secret disk order (36! orderings, about 2^138), a fixed setting is a monoalphabetic substitution, and `encSyms_eq_iff` is exactly why frequency analysis breaks it. Alberti's mid-message key change (Level 5) is the historical fix, and it only blunts this.
* Security needs a different kind of statement: a *game* between a challenger and an adversary, and a bound on the adversary's advantage. For the one-time pad that bound is exactly zero (perfect secrecy). The HashCloak tutorial proves OTP correctness in Lean and builds toward this.
* For real ciphers, the bound is *computational*: no **efficient** adversary wins with more than negligible advantage. No one can prove that outright today (it would imply P ≠ NP). What we prove are *reductions*: "if you break this, you break that hard problem". Lean can check the reduction; it cannot check the hardness assumption.
* The closing paper (eprint 2025/1700) formalizes in Lean 4 the bridge from simple symbolic proofs (messages as terms, perfect encryption) to computationally sound ones, with garbled circuits as the case study. That bridge is the gap between Level 3 and real security.

### Common snags

* **No goal shown**: open the Infoview (`Ctrl+Shift+Enter`), put the cursor inside the `by` block.
* **Opened a single file, not the folder**: imports fail. Open the project folder.
* **Typing Greek letters**: in VS Code type `\theta`, `\sigma`, `\xi`, `\delta` and space. Or copy from `Basic.lean`.
* **Wrong toolchain**: `lean-toolchain` pins 4.35.0; elan fetches it automatically when online. Offline, use the USB workflow above.
* **`decide` is slow or fails**: it should not be here (Level 1 checks take well under a second). If it fails, the statement is false: `#eval` both sides.
* **`simp` made no progress**: unfold the definition first, or pass the hypothesis (`simp [h]`).
* **The brute-force output looks like a Caesar shift**: it is. Once the disk order is public, Alberti with one setting is a Caesar cipher on the outer ring. Good discussion starter.

## Reading

* Elena (HashCloak), *Tutorial: Introduction to Formal Verification with Lean (Part 1)*, 2026: Lean 4 from zero, one-time pad correctness, `ZMod 2` vectors (uses Mathlib).
  https://hashcloak.com/blog/tutorial-introduction-to-formal-verification-with-lean-(part-1)
* S. Dziembowski, G. Fabiański, D. Micciancio, R. Stefański, *Computationally-Sound Symbolic Cryptography in Lean*, IACR ePrint 2025/1700.
  https://eprint.iacr.org/2025/1700
* *Functional Programming in Lean* and *Theorem Proving in Lean 4*: https://lean-lang.org/documentation/
* The coin and paper disk: `cryptography.church/alberti.html`.

## Verified

Built here with `lake build` on Lean 4.35.0 (`leanprover/lean4:v4.35.0`, commit `eb6cafb`), Lake 5.0.0, elan 4.2.4, Linux x86_64:
`Build completed successfully (6 jobs)`. `Basic` and `Solutions` build with no warnings; `Exercises` has only `sorry` warnings.
`live/AlbertiLive.lean` compiles with the same toolchain. Not tested: macOS, Windows, live.lean-lang.org.
